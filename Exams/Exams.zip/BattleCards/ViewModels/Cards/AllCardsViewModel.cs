﻿namespace BattleCards.ViewModels.Cards
{
    using System.Collections.Generic;

    public class AllCardsViewModel
    {
        public List<CardViewModel> AllCards { get; set; }
    }
}
